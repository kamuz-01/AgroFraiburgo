package org.main.enums;

public enum TipoUsuario {
    CONSUMIDOR,
    PRODUTOR,
    MODERADOR
}