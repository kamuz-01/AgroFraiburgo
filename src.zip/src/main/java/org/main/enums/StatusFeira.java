package org.main.enums;

public enum StatusFeira {
    EM_ANDAMENTO,
    SUSPENSA,
    ENCERRADO
}