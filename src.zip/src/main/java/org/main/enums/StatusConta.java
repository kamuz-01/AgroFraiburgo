package org.main.enums;

public enum StatusConta {
	ATIVO,
	PENDENTE,
	BLOQUEADO,
	REJEITADO
}