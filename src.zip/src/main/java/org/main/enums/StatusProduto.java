package org.main.enums;

public enum StatusProduto {
	COM_ESTOQUE, 
	SEM_ESTOQUE
}