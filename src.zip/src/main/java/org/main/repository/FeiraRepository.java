package org.main.repository;

import org.main.models.Feira;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeiraRepository extends JpaRepository<Feira, Integer> {
}